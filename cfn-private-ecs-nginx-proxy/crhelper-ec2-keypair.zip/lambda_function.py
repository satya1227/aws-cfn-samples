from crhelper import CfnResource
import boto3 
from botocore.errorfactory import ClientError

helper = CfnResource()

@helper.create
def create_ec2_keypair(event, _):

    MyKeyName=event['ResourceProperties']['KeypairName']      #'test_key_pair333'
    bucket_name=event['ResourceProperties']['S3BucketName']   #'msp-ec2-keypair'
    s3 = boto3.resource('s3') 
    bucket = s3.Bucket(bucket_name)
   
    key = MyKeyName+'.pem'
    objs = list(bucket.objects.filter(Prefix=key))

    s3 = boto3.client('s3')
    try:
        s3.head_object(Bucket=bucket_name, Key=key)
        print("Exists!!")
        helper.Data['EC2KeyPairName'] = key
        helper.Data['OutputMessage'] = "Key Pair exists!"
        return 0
    except ClientError:
        # Not found
        print("Do not exist! Creating new keypair")
        pass
        create_keypair(MyKeyName,bucket_name)
 
    helper.Data['EC2KeyPairName'] = key
    helper.Data['OutputMessage'] = "New Key Pair created"
        
@helper.update
def create_ec2_keypair(event, _):

    MyKeyName=event['ResourceProperties']['KeypairName']      #'test_key_pair333'
    bucket_name=event['ResourceProperties']['S3BucketName']   #'msp-ec2-keypair'
    s3 = boto3.resource('s3') 
    bucket = s3.Bucket(bucket_name)
   
    key = MyKeyName+'.pem'
    objs = list(bucket.objects.filter(Prefix=key))

    s3 = boto3.client('s3')
    try:
        s3.head_object(Bucket=bucket_name, Key=key)
        print("Exists!!")
        helper.Data['EC2KeyPairName'] = key
        helper.Data['OutputMessage'] = "Key Pair exists!"
        return 0
    except ClientError:
        # Not found
        print("Do not exist! Creating new keypair")
        pass
        create_keypair(MyKeyName,bucket_name)
 
    helper.Data['EC2KeyPairName'] = key
    helper.Data['OutputMessage'] = "New Key Pair created"
    
@helper.delete
def no_op(_, __):
    pass

def handler(event, context):
    helper(event, context)

def create_keypair(MyKeyName,bucket_name):
    ec2 = boto3.client('ec2')
    pem_file=MyKeyName+'.pem'
    new_keypair = ec2.create_key_pair(KeyName=MyKeyName)
    mystring=str(new_keypair['KeyMaterial'])
    #print(mystring) 
    encoded_string = str(new_keypair) #mystring #mystring.encode("utf-8")
    s3client = boto3.client('s3')
    s3client.put_object(Key=pem_file,Bucket=bucket_name, Body=str(mystring))
    